--QUESTION 1
CREATE TABLE Customer (
    cust_id VARCHAR2(10) PRIMARY KEY,
    cust_fname VARCHAR2(50),
    cust_sname VARCHAR2(50),
    cust_address VARCHAR2(100),
    cust_contact VARCHAR2(20)
);
INSERT INTO Customer (cust_id, cust_fname, cust_sname, cust_address, cust_contact) VALUES ('C115', 'Heinrich', 'Willis', '3 Main Road', '0821253659');
INSERT INTO Customer (cust_id, cust_fname, cust_sname, cust_address, cust_contact) VALUES ('C116', 'David', 'Watson', '13 Cape Road', '0769658547');
INSERT INTO Customer (cust_id, cust_fname, cust_sname, cust_address, cust_contact) VALUES ('C117', 'Waldo', 'Smith', '3 Mountain Road', '0863256574');
INSERT INTO Customer (cust_id, cust_fname, cust_sname, cust_address, cust_contact) VALUES ('C118', 'Alex', 'Hanson', '8 Circle Road', '0762356587');
INSERT INTO Customer (cust_id, cust_fname, cust_sname, cust_address, cust_contact) VALUES ('C119', 'Kuhle', 'Bitterhout', '15 Main Road', '0821235258');
INSERT INTO Customer (cust_id, cust_fname, cust_sname, cust_address, cust_contact) VALUES ('C120', 'Thando', 'Zolani', '88 Summer Road', '0847541254');
INSERT INTO Customer (cust_id, cust_fname, cust_sname, cust_address, cust_contact) VALUES ('C121', 'Philip', 'Jackson', '3 Long Road', '0745556658');
INSERT INTO Customer (cust_id, cust_fname, cust_sname, cust_address, cust_contact) VALUES ('C122', 'Sarah', 'Jones', '7 Sea Road', '0814745745');
INSERT INTO Customer (cust_id, cust_fname, cust_sname, cust_address, cust_contact) VALUES ('C123', 'Catherine', 'Howard', '31 Lake Side Road', '0822232521');

   SELECT * FROM customer;
   
   
    CREATE TABLE Instructor (
    ins_ID INT PRIMARY KEY,
    ins_fname VARCHAR2(50),
    ins_sname VARCHAR2(50),
    ins_contact VARCHAR2(20),
    ins_level INT
);

INSERT INTO Instructor (ins_ID, ins_fname, ins_sname, ins_contact, ins_level) VALUES (101, 'James', 'Willis', '0843569851', 7);
INSERT INTO Instructor (ins_ID, ins_fname, ins_sname, ins_contact, ins_level) VALUES (102, 'Sam', 'Wait', '0763698521', 2);
INSERT INTO Instructor (ins_ID, ins_fname, ins_sname, ins_contact, ins_level) VALUES (103, 'Sally', 'Gumede', '0786598521', 8);
INSERT INTO Instructor (ins_ID, ins_fname, ins_sname, ins_contact, ins_level) VALUES (104, 'Bob', 'Du Preez', '0796369857', 3);
INSERT INTO Instructor (ins_ID, ins_fname, ins_sname, ins_contact, ins_level) VALUES (105, 'Simon', 'Jones', '0826598741', 9);
 
   
SELECT * FROM INSTRUCTOR;
   
   
CREATE TABLE Dive (
    dive_id INT PRIMARY KEY,
    dive_name VARCHAR2(100),
    dive_duration VARCHAR2(50),
    dive_location VARCHAR2(100),
    dive_exp_level INT,
    dive_cost INT
);

INSERT INTO Dive (dive_id, dive_name, dive_duration, dive_location, dive_exp_level, dive_cost) VALUES (550, 'Shark Dive', '3 hours', 'Shark Point', 8, 500);
INSERT INTO Dive (dive_id, dive_name, dive_duration, dive_location, dive_exp_level, dive_cost) VALUES (551, 'Coral Dive', '1 hour', 'Break Point', 7, 300);
INSERT INTO Dive (dive_id, dive_name, dive_duration, dive_location, dive_exp_level, dive_cost) VALUES (552, 'Wave', '2 hours', 'Ship wreck ally', 3, 800);
INSERT INTO Dive (dive_id, dive_name, dive_duration, dive_location, dive_exp_level, dive_cost) VALUES (553, 'Underwater Exploration', '1 hour', 'Coral ally', 2, 250);
INSERT INTO Dive (dive_id, dive_name, dive_duration, dive_location, dive_exp_level, dive_cost) VALUES (554, 'Underwater Adventure', '3 hours', 'Sandy Beach', 3, 750);
INSERT INTO Dive (dive_id, dive_name, dive_duration, dive_location, dive_exp_level, dive_cost) VALUES (555, 'Deep Blue Ocean', '30 minutes', 'Lazy Waves', 2, 120);
INSERT INTO Dive (dive_id, dive_name, dive_duration, dive_location, dive_exp_level, dive_cost) VALUES (556, 'Rough Seas', '1 hour', 'Pipe', 9, 700);
INSERT INTO Dive (dive_id, dive_name, dive_duration, dive_location, dive_exp_level, dive_cost) VALUES (557, 'White Water', '2 hours', 'Drifts', 5, 200);
INSERT INTO Dive (dive_id, dive_name, dive_duration, dive_location, dive_exp_level, dive_cost) VALUES (558, 'Current Adventure', '2 hours', 'Rock Lands', 3, 150);

   
   SELECT * FROM dive;
   
  CREATE TABLE Dive_Event (
    dive_event_id VARCHAR2(10) PRIMARY KEY,
    dive_date DATE,
    dive_participants INT,
    ins_ID INT,
    cust_id VARCHAR2(10),
    dive_ID INT,
    FOREIGN KEY (ins_ID) REFERENCES Instructor(ins_ID),
    FOREIGN KEY (cust_id) REFERENCES Customer(cust_id),
    FOREIGN KEY (dive_ID) REFERENCES Dive(dive_ID)
);

INSERT INTO Dive_Event (dive_event_id, dive_date, dive_participants, ins_ID, cust_id, dive_ID) VALUES ('de_101', TO_DATE('15-Jul-17', 'DD-Mon-YY'), 5, 103, 'C115', 558);
INSERT INTO Dive_Event (dive_event_id, dive_date, dive_participants, ins_ID, cust_id, dive_ID) VALUES ('de_102', TO_DATE('16-Jul-17', 'DD-Mon-YY'), 7, 102, 'C117', 555);
INSERT INTO Dive_Event (dive_event_id, dive_date, dive_participants, ins_ID, cust_id, dive_ID) VALUES ('de_103', TO_DATE('18-Jul-17', 'DD-Mon-YY'), 8, 104, 'C118', 552);
INSERT INTO Dive_Event (dive_event_id, dive_date, dive_participants, ins_ID, cust_id, dive_ID) VALUES ('de_104', TO_DATE('19-Jul-17', 'DD-Mon-YY'), 3, 101, 'C119', 551);
INSERT INTO Dive_Event (dive_event_id, dive_date, dive_participants, ins_ID, cust_id, dive_ID) VALUES ('de_105', TO_DATE('21-Jul-17', 'DD-Mon-YY'), 5, 104, 'C121', 558);
INSERT INTO Dive_Event (dive_event_id, dive_date, dive_participants, ins_ID, cust_id, dive_ID) VALUES ('de_106', TO_DATE('22-Jul-17', 'DD-Mon-YY'), 8, 105, 'C120', 556);
INSERT INTO Dive_Event (dive_event_id, dive_date, dive_participants, ins_ID, cust_id, dive_ID) VALUES ('de_107', TO_DATE('25-Jul-17', 'DD-Mon-YY'), 10, 105, 'C115', 554);
INSERT INTO Dive_Event (dive_event_id, dive_date, dive_participants, ins_ID, cust_id, dive_ID) VALUES ('de_108', TO_DATE('27-Jul-17', 'DD-Mon-YY'), 5, 101, 'C122', 552);
INSERT INTO Dive_Event (dive_event_id, dive_date, dive_participants, ins_ID, cust_id, dive_ID) VALUES ('de_109', TO_DATE('28-Jul-17', 'DD-Mon-YY'), 3, 102, 'C123', 553);


   SELECT * FROM dive_event;
   
--QUESTION 2
   
   
ALTER SESSION SET "_ORACLE_SCRIPT"=TRUE;

--Enable Oracle to display results of Query and block execution in results plane

SET SERVEROUTPUT ON;

--Create a user called SchemaName to be assigned a schemma role
CREATE USER ADMINISTRATOR IDENTIFIED BY Admin1;
GRANT ALL PRIVILEGES TO ADMINISTRATOR ;
COMMIT;

--AMINITRATOR HAS ACCESS TO ALL THE TABLES

--

DROP USER  ADMINISTRATOR  CASCADE;

ALTER SESSION SET "_ORACLE_SCRIPT"=TRUE;



SET SERVEROUTPUT ON;

CREATE USER general_user IDENTIFIED BY User1;
GRANT CREATE SESSION TO general_user;
GRANT SELECT ON Instructor TO general_user;
GRANT SELECT ON Customer TO general_user;
GRANT SELECT ON Dive TO general_user;
GRANT SELECT ON Dive_Event TO general_user;
GRANT INSERT ON Dive_Event TO general_user;
GRANT UPDATE ON Dive_Event TO general_user;
GRANT DELETE ON Dive_Event TO general_user;
COMMIT;

-- General users have FULL access to the DIVE_EVENT TABLE UT LIMITED ON THE OTHER TABLES



DROP USER  general_user  CASCADE;

--QUESTION 3
ALTER SESSION SET "_ORACLE_SCRIPT"=TRUE;

SET SERVEROUTPUT ON;

SELECT 
    i.ins_fname || ' ' || i.ins_sname AS instructor_full_name,
    c.cust_fname || ' ' || c.cust_sname AS customer_full_name,
    d.dive_location,
    de.dive_participants
FROM 
    Dive_Event de
JOIN 
    Instructor i ON de.ins_ID = i.ins_ID
JOIN 
    Customer c ON de.cust_id = c.cust_id
JOIN 
    Dive d ON de.dive_ID = d.dive_id
WHERE 
    de.dive_participants BETWEEN 8 AND 10;
 
    
--Question 4

DECLARE
    v_dive_name Dive.dive_name%TYPE;
    v_dive_date Dive_Event.dive_date%TYPE;
BEGIN
    FOR rec IN (
        SELECT d.dive_name, de.dive_date
        FROM Dive_Event de
        JOIN Dive d ON de.dive_ID = d.dive_ID
        WHERE de.dive_participants >= 10
    ) LOOP
        v_dive_name := rec.dive_name;
        v_dive_date := rec.dive_date;

        -- Displaying the dive name and allocated date
        DBMS_OUTPUT.PUT_LINE('Dive Name: ' || v_dive_name || ', Allocated Date: ' || TO_CHAR(v_dive_date, 'DD-Mon-YYYY'));
    END LOOP;
END;
/


--QUESTION 5

SET SERVEROUTPUT ON;

DECLARE
    v_cust_fullname VARCHAR2(100);
    v_dive_name Dive.dive_name%TYPE;
    v_dive_participants Dive_Event.dive_participants%TYPE;
    v_dive_cost Dive.dive_cost%TYPE;
    v_required_instructors INT;
BEGIN
    FOR rec IN (
        SELECT c.cust_fname || ' ' || c.cust_sname AS cust_fullname,
               d.dive_name,
               de.dive_participants,
               d.dive_cost
        FROM Dive_Event de
        JOIN Customer c ON de.cust_id = c.cust_id
        JOIN Dive d ON de.dive_ID = d.dive_ID
        WHERE d.dive_cost > 500
    ) LOOP
        v_cust_fullname := rec.cust_fullname;
        v_dive_name := rec.dive_name;
        v_dive_participants := rec.dive_participants;
        v_dive_cost := rec.dive_cost;

        -- Determine number of required instructors based on participants
        IF v_dive_participants <= 4 THEN
            v_required_instructors := 1;
        ELSIF v_dive_participants >= 5 AND v_dive_participants <= 7 THEN
            v_required_instructors := 2;
        ELSE
            v_required_instructors := 3;
        END IF;
        
        -- Displaying the report
        DBMS_OUTPUT.PUT_LINE('Customer: ' || v_cust_fullname || ', Dive Event: ' || v_dive_name || ', Participants: ' || v_dive_participants || ', Required Instructors: ' || v_required_instructors);
    END LOOP;
END;
/

--Question 6
CREATE VIEW Vw_Dive_Event AS
SELECT 
    de.ins_ID,
    de.cust_id,
    c.cust_address,
    d.dive_duration
FROM 
    Dive_Event de
JOIN 
    Customer c ON de.cust_id = c.cust_id
JOIN 
    Dive d ON de.dive_ID = d.dive_ID
WHERE 
    de.dive_date < TO_DATE('19-Jul-2017', 'DD-Mon-YYYY');
    
    SELECT * FROM Vw_Dive_Event;


--QUESTION 7

-- Create or replace the trigger
CREATE OR REPLACE TRIGGER New_Dive_Event
BEFORE INSERT ON Dive_Event
FOR EACH ROW
BEGIN
    IF :NEW.dive_participants <= 0 THEN
        RAISE_APPLICATION_ERROR(-20001, 'Participants cannot be 0 or less.');
    ELSIF :NEW.dive_participants > 20 THEN
        RAISE_APPLICATION_ERROR(-20002, 'Participants cannot exceed 20.');
    END IF;
END;
/

INSERT INTO Dive_Event (dive_event_id, dive_date, dive_participants, ins_ID, cust_id_, dive_ID)
VALUES ('de_110', TO_DATE('01-Aug-2017', 'DD-Mon-YYYY'), 5, 101, 'C115', 554);
-- This should succeed without errors.

INSERT INTO Dive_Event (dive_event_id, dive_date, dive_participants, ins_ID, cust_id, dive_ID)
VALUES ('de_111', TO_DATE('05-Aug-2017', 'DD-Mon-YYYY'), 0, 102, 'C116', 552);
-- This should raise an error: Participants cannot be 0 or less.

INSERT INTO Dive_Event (dive_event_id, dive_date, dive_participants, ins_ID, cust_id, dive_ID)
VALUES ('de_112', TO_DATE('10-Aug-2017', 'DD-Mon-YYYY'), 25, 103, 'C117', 553);
-- This should raise an error: Participants cannot exceed 20.

--QUESTION 8

CREATE OR REPLACE PROCEDURE sp_Customer_Details(
    p_cust_id IN Customer.cust_id%TYPE,
    p_dive_name IN Dive.dive_name%TYPE,
    p_dive_date IN DATE
)
IS
    v_cust_fname Customer.cust_fname%TYPE;
    v_cust_sname Customer.cust_sname%TYPE;
    v_cust_address Customer.cust_address%TYPE;
    v_dive_duration Dive.dive_duration%TYPE;
BEGIN
    -- Retrieve customer details for the specified customer ID
    SELECT c.cust_fname, c.cust_sname, c.cust_address
    INTO v_cust_fname, v_cust_sname, v_cust_address
    FROM Customer c
    WHERE c.cust_id = p_cust_id;
    
    -- Retrieve dive duration for the specified dive name and date
    SELECT d.dive_duration
    INTO v_dive_duration
    FROM Dive d
    WHERE d.dive_name = p_dive_name;
    
    -- Display customer details and dive duration
    DBMS_OUTPUT.PUT_LINE('Customer Name: ' || v_cust_fname || ' ' || v_cust_sname);
    DBMS_OUTPUT.PUT_LINE('Customer Address: ' || v_cust_address);
    DBMS_OUTPUT.PUT_LINE('Dive Name: ' || p_dive_name);
    DBMS_OUTPUT.PUT_LINE('Dive Date: ' || TO_CHAR(p_dive_date, 'DD-Mon-YYYY'));
    DBMS_OUTPUT.PUT_LINE('Dive Duration: ' || v_dive_duration);
    
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        DBMS_OUTPUT.PUT_LINE('No customer found with ID ' || p_cust_id);
END sp_Customer_Details;
/

BEGIN
    sp_Customer_Details('C115', 'Deep Blue Ocean', TO_DATE('21-Jul-2017', 'DD-Mon-YYYY'));
END;
/

--QUESTION 9

CREATE OR REPLACE FUNCTION calculateDiveCost(
    p_dive_id IN Dive.dive_id%TYPE,
    p_participants IN INT
) RETURN INT
IS
    v_dive_cost Dive.dive_cost%TYPE;
    v_total_cost INT;
BEGIN
    -- Retrieve the cost of the dive based on dive_id
    SELECT dive_cost INTO v_dive_cost FROM Dive WHERE dive_id = p_dive_id;

    -- Validate the number of participants
    IF p_participants <= 0 THEN
        RAISE_APPLICATION_ERROR(-20001, 'Participants cannot be 0 or less.');
    END IF;

    -- Calculate total cost with discount logic based on number of participants
    IF p_participants <= 4 THEN
        v_total_cost := v_dive_cost * p_participants;
    ELSIF p_participants >= 5 AND p_participants <= 7 THEN
        v_total_cost := v_dive_cost * p_participants * 0.9; -- 10% discount for 5-7 participants
    ELSE
        v_total_cost := v_dive_cost * p_participants * 0.8; -- 20% discount for 8 or more participants
    END IF;

    RETURN v_total_cost;
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        RAISE_APPLICATION_ERROR(-20002, 'Invalid dive ID. Dive not found.');
    WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20003, 'An error occurred: ' || SQLERRM);
END calculateDiveCost;
/

-- Example 1: Calculate cost for Dive ID 554 (Deep Blue Ocean) with 5 participants
DECLARE
    v_cost INT;
BEGIN
    v_cost := calculateDiveCost(554, 5);
    DBMS_OUTPUT.PUT_LINE('Total cost for the dive event: ' || v_cost);
END;
/

-- Example 2: Calculate cost for Dive ID 552 (Wave) with 10 participants
DECLARE
    v_cost INT;
BEGIN
    v_cost := calculateDiveCost(552, 10);
    DBMS_OUTPUT.PUT_LINE('Total cost for the dive event: ' || v_cost);
END;
/

--QUESTION 10













    
    





   
   
   
   